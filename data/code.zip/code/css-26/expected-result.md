#css

```css
.photo,
.contacts,
.skills {
  margin-bottom: 60px;
}

.contacts,
.skills  {
  padding-left: 40px;
}
```
