#css

```css
.bio,
.projects,
.jobs,
.education {
  margin-bottom: 60px;
}

.right-side {
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;
}
```
