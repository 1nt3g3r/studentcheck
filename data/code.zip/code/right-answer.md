## Day 1

    1. Theme:  h1
```html
    <h1>Anton Chornyi</h1>
```
    2.  Theme:  p
```html
<h1>Anton Chornyi</h1>
<p>Front-end developer</p>
<p>
   Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet odio adipisci
   illo, earum atque quae, sequi magni consectetur sit perferendis sunt laborum
   ipsum quas. A incidunt temporibus aut harum ad.
 </p>
```
    3.  Theme:  h3
```html
<h2>Projects</h2>
```
    4.  Theme:  ol li
```html
<h2>Projects</h2>
<ol>
  <li>https://lovecamp.allinsol.com</li>
  <li>https://cryptohub.goit.ua</li>
  <li>https://kidslike.goit.co.ua</li>
</ol>
```    
    5.  Theme:  a
```html
<h2>Projects</h2>
<ol>
  <li>
    <a href="https://lovecamp.allinsol.com">https://lovecamp.allinsol.com</a>
  </li>
  <li>
    <a href="https://cryptohub.goit.ua">https://cryptohub.goit.ua</a>
  </li>
  <li>
    <a href="https://kidslike.goit.co.ua">https://kidslike.goit.co.ua</a>
  </li>
</ol>
```    
    6.  Theme:  h3
```html
<h2>Employment history</h2>
<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
```    
    7.  Theme:  ul li
```html
<h2>Employment history</h2>

<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
<ul>
  <li>Lorem ipsum dolor sit amet.</li>
  <li>Quaerat corrupti eum harum eveniet?</li>
  <li>Sit quasi libero facilis ea?</li>
</ul>
```    
    8.  Theme:  повтор
```html
<h2>Employment history</h2>
<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
<ul>
  <li>Lorem ipsum dolor sit amet.</li>
  <li>Quaerat corrupti eum harum eveniet?</li>
  <li>Sit quasi libero facilis ea?</li>
</ul>
<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
<ul>
  <li>Lorem ipsum dolor sit amet.</li>
  <li>Quaerat corrupti eum harum eveniet?</li>
  <li>Sit quasi libero facilis ea?</li>
</ul>
<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
<ul>
  <li>Lorem ipsum dolor sit amet.</li>
  <li>Quaerat corrupti eum harum eveniet?</li>
  <li>Sit quasi libero facilis ea?</li>
</ul>
```    
    9.  Theme:  повтор
```html
<h2>Education</h2>
<h3>Manager, Kharkiv</h3>
<p>September 2019 - up to now</p>
<h3>Manager, Kharkiv</h3>
<p>September 2019 - up to now</p>
```
    10.  Theme:  section
```html
<section>
  <h1>Anton Chornyi</h1>
  <p>Front-end developer</p>
  <p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet odio adipisci
    illo, earum atque quae, sequi magni consectetur sit perferendis sunt laborum
    ipsum quas. A incidunt temporibus aut harum ad.
  </p>
</section>
<section>
  <h2>Project</h2>
  <ol>
    <li>
      <a href="https://lovecamp.allinsol.com/">https://lovecamp.allinsol.com</a>
    </li>
    <li>
      <a href="https://cryptohub.goit.ua/">https://cryptohub.goit.ua</a>
    </li>
    <li>
      <a href="https://kidslike.goit.co.ua/">https://kidslike.goit.co.ua</a>
    </li>
  </ol>
</section>
<section>
  <h2>Employment history</h2>
  <h3>Front-end developer at Freelance</h3>
  <p>September 2019 - up to now</p>
  <ul>
    <li>Lorem ipsum dolor sit amet.</li>
    <li>Quaerat corrupti eum harum eveniet?</li>
    <li>Sit quasi libero facilis ea?</li>
  </ul>
  <h3>Front-end developer at Freelance</h3>
  <p>September 2019 - up to now</p>
  <ul>
    <li>Lorem ipsum dolor sit amet.</li>
    <li>Quaerat corrupti eum harum eveniet?</li>
    <li>Sit quasi libero facilis ea?</li>
  </ul>
  <h3>Front-end developer at Freelance</h3>
  <p>September 2019 - up to now</p>
  <ul>
    <li>Lorem ipsum dolor sit amet.</li>
    <li>Quaerat corrupti eum harum eveniet?</li>
    <li>Sit quasi libero facilis ea?</li>
  </ul>
</section>
<section>
  <h2>Education</h2>
  <h3>Manager, Kharkiv</h3>
  <p>September 2019 - up to now</p>
  <h3>Manager, Kharkiv</h3>
  <p>September 2019 - up to now</p>
</section>
```

## Day 2

   1. (11)  Theme:  img
```html
<img
  src="/img/code/html-11/photo.jpg"
  alt="Моя фотография"
  width="370"
/>
```
   2. (12)  Theme:  повтор
```html
<section>
  <h2>Contacts</h2>

  <ul>
    <li>Phone: +38 095 111 11 11</li>
    <li>Email: chornyiav@gmail.com</li>
  </ul>
</section>
```
    3. (13)  Theme:  href tel mailto
```html
<section>
  <h2>Contacts</h2>

  <ul>
    <li>Phone: <a href="tel:+380951111111">+38 095 111 11 11</a></li>
    <li>Email: <a href="mailto:chornyiav@gmail.com">chornyiav@gmail.com</a></li>
  </ul>
</section>
```
    4. (14)  Theme:  повтор Tech Skills
```html
<section>
  <h2>Tech skills</h2>

  <ul>
    <li>HTML</li>
    <li>CSS</li>
    <li>Git</li>
    <li>JavaScript</li>
    <li>React</li>
    <li>Node.js</li>
  </ul>
</section>

<section>
  <h2>Soft skills</h2>

  <ul>
    <li>Scrum</li>
    <li>Agile</li>
    <li>GTD</li>
    <li>Teamwork</li>
  </ul>
</section>
```
   5. (15) Theme:  aside .container
```html
<div class="container">
  <aside class="left-side">
   <!-- Разметка фото -->
   <!-- Разметка контакты -->
   <!-- Разметкатех. навыков -->
   <!-- Разметка софт. навыков -->
  </aside>
  <div class="right-side">
     <!-- Разметка биографии -->
     <!-- Разметка проекты -->
     <!-- Разметка работа -->
     <!-- Разметка учеба -->
  </div>
</div>
```


## Day 3

  1. (css-1) Theme: font-size
```css
.bio-title {
  font-size: 45px;
}

.bio-occupation {
  font-size: 14px;
}

.bio-about {
  font-size: 14px;
}
```
  2. (css-2) Theme: line-height
```css
.bio-title {
  font-size: 45px;
  line-height: 2;
}

.bio-occupation {
  font-size: 14px;
  line-height: 1.714;
}

.bio-about {
  font-size: 14px;
  line-height: 1.714;
}
```
  3. (css-3) Theme: color
```css
.bio-title {
  font-size: 45px;
  line-height: 2;
  color: #2a2a2a;
}

.bio-occupation {
  font-size: 14px;
  line-height: 1.714;
  color: #2a2a2a;
}

.bio-about {
  font-size: 14px;
  line-height: 1.714;
  color: #595959;
}
```
  4. (css-4) Theme: DRY
```css
.bio-title {
  font-size: 45px;
  line-height: 2;
}

.bio-title ,
.bio-occupation {
  color: #2a2a2a;
}

.bio-occupation,
.bio-about {
  font-size: 14px;
  line-height: 1.714;
}

.bio-about {
  color: #595959;
}
```
  5. (css-5) Theme: margin
```css
.bio-title {
  font-size: 45px;
  line-height: 2;

  margin-bottom: 20px;
}

.bio-occupation {
  margin-bottom: 27px;
}

.bio-title ,
.bio-occupation {
  color: #2a2a2a;
}

.bio-occupation,
.bio-about {
  font-size: 14px;
  line-height: 1.714;
}

.bio-about {
  color: #595959;
}
```
  6. (css-6) Theme: projects - все стили сразу
```css
.projects-title {
  font-size: 22px;
  line-height: 1.091;
  color: #2a2a2a;
  margin-bottom: 14px;
}

.projects-link {
  font-size: 14px;
  line-height: 1.714;
  color: #220fdc;
}
```
  7. (css-7) Theme: псевдокласс
```css
.contacts-link {
  color: #595959;
  text-decoration: none;
}

.contacts-link:hover {
  color: #ff6b08;
}
```
  8. (css-8) Theme: стили + псевдокласс
```css
.projects-title {
  margin-bottom: 14px;
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;
}

.projects-link {
  color: #220fdc;
  font-size: 14px;
  line-height: 1.714;
}

.projects-link:hover {
  color: #ff6b08;
}
```
  9. (css-9) Theme: font-size + line-height
```css
.jobs-title {
  font-size: 22px;
  line-height: 1.091;
}

.jobs-occupation {
  font-size: 16px;
  line-height: 1.5;
}

.jobs-time {
  font-size: 12px;
  line-height: 2;
}

.experience-item {
  font-size: 14px;
  line-height: 1.714;
}
```
  10. (css-10) Theme: стили + color
```css
.jobs-title {
  color: #2a2a2a;

  font-size: 22px;
  line-height: 1.091;
}

.jobs-occupation {
  color: #2a2a2a;

  font-size: 16px;
  line-height: 1.5;
}

.jobs-time {
  color: #828282;

  font-size: 12px;
  line-height: 2;
}

.experience-item {
  color: #595959;

  font-size: 14px;
  line-height: 1.714;
}
```
  11. (css-11) Theme: стили + .accent {color}
```css
.jobs-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;
}

.jobs-occupation {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;
}

.jobs-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;
}

.experience-item {
  color: #595959;
  font-size: 14px;
  line-height: 1.714;
}

.accent {
  color: #ff6b08;
}
```
  12. (css-12) Theme: стили + margin-bottom
```css
.jobs-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;

  margin-bottom: 26px;
}

.jobs-occupation {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;

  margin-bottom: 16px;
}

.jobs-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;

  margin-bottom: 18px;
}

.experience-item {
  color: #595959;
  font-size: 14px;
  line-height: 1.714;

  margin-bottom: 10px;
}

.accent {
  color: #ff6b08;
}
```
  13. (css-13) Theme: class to html
```html
<section class="jobs">
  <h2 class="jobs-title">Employment history</h2>

  <h3 class="jobs-occupation">
    Front-end developer at <span class="accent">Freelance</span>
  </h3>
  <p class="jobs-time">September 2019 - up to now</p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet.</li>
    <li class="experience-item">Quaerat corrupti eum harum eveniet?</li>
    <li class="experience-item">Sit quasi libero facilis ea?</li>
  </ul>

  <h3 class="jobs-occupation">
    Front-end developer at <span class="accent">Freelance</span>
  </h3>
  <p class="jobs-time">September 2019 - up to now</p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet.</li>
    <li class="experience-item">Quaerat corrupti eum harum eveniet?</li>
    <li class="experience-item">Sit quasi libero facilis ea?</li>
  </ul>

  <h3 class="jobs-occupation">
    Front-end developer at <span class="accent">Freelance</span>
  </h3>
  <p class="jobs-time">September 2019 - up to now</p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet.</li>
    <li class="experience-item">Quaerat corrupti eum harum eveniet?</li>
    <li class="experience-item">Sit quasi libero facilis ea?</li>
  </ul>
</section>
```
  14. (css-14) Theme: projects - experience + margin-bottom
```css
.jobs-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;

  margin-bottom: 26px;
}

.jobs-occupation {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;

  margin-bottom: 16px;
}

.jobs-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;

  margin-bottom: 18px;
}

.experience-item {
  color: #595959;
  font-size: 14px;
  line-height: 1.714;

  margin-bottom: 10px;
}

.accent {
  color: #ff6b08;
}

.experience {
  margin-bottom: 28px;
}
```
  15. (css-15) Theme: education
```css
.education-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091

  margin-bottom: 26px;
}

.education-degree {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;

  margin-bottom: 16px;
}

.education-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;

  margin-bottom: 18px;
}

.accent {
  color: #ff6b08;
}
```
  16. (css-16) Theme: final margin-bottom для section
```css
.bio,
.projects,
.jobs,
.education {
  margin-bottom: 60px;
}
```
  17. (css-17) Theme: final wrapper + padding
```css
.bio,
.projects,
.jobs,
.education {
  margin-bottom: 60px;
}

.right-side {
  padding-left: 80px;
  paddding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;
}
```

## Day 4
  1. (css-18) Theme: aside
```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
}
```
  2. (css-19) Theme: photo
```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
}

.photo {
  width: 370px;
}
```
  3. (css-20) Theme: font-size line-height
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
}

.contacts-title {
  font-size: 22px;
  line-height: 1.091;
}

.contacts-item {
  font-size: 14px;
  line-height: 1.714;
}
```
  4. (css-21) Theme: color
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.contacts-title {
  font-size: 22px;
  line-height: 1.091;
}

.contacts-item {
  font-size: 14px;
  line-height: 1.714;
}

.contacts-link {
  color: #fff;
  opacity: 0.6;
}
```
  5. (css-22) Theme: hover + color
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.contacts-title {
  font-size: 22px;
  line-height: 1.091;
}

.contacts-item {
  font-size: 14px;
  line-height: 1.714;
}

.contacts-link {
  color: #fff;
  opacity: 0.6;
}

.contacts-link:hover {
  opacity: 1;
}
```
  6. (css-23) Theme: цвета и текст
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills-title {
  font-size: 22px;
  line-height: 1.091;
}

.skills-item {
  font-size: 14px;
  line-height: 1.714;
}
```
  7. (css-24) Theme: before
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills-title {
  font-size: 22px;
  line-height: 1.091;
}

.skills-item {
  font-size: 14px;
  line-height: 1.714;
}

.skills-list {
  list-style: none;
  padding-left: 0;
}

.skills-item::before {
  content: '\2022';
  margin-right: 8px;
  color: #ff6b08;
  font-size: 18px;
}
```
  8. (css-25) Theme: section + margin-bottom
```css
.photo,
.contacts,
.skills {
  margin-bottom: 60px;
}
```
  9. (css-26) Theme: padding
```css
.photo,
.contacts,
.skills {
  margin-bottom: 60px;
}

.contacts,
.skills  {
  padding-left: 40px;
}
```
  10. (css-27) Theme: flexbox пример flexbox
```css
.container {
  display: flex;
}

.left-side {
  background-color: #1e2939;
  color: #fff;

  width: 370px;
}

.right-side {
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;

  width: 830px;
}

.contacts, .skills {
    padding-left: 40px;
}
```
  11. (css-28) Theme: Центрирование контейнера
```css
.container {
  display: flex;
  width: 1200px;
  margin-left: auto;
  margin-right: auto;
}

.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.right-side {
  width: 830px;
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;
}

.contacts, .skills {
    padding-left: 40px;
}
```
  12. (css-29) Theme: фон body, container и тень
```css
body {
  background-color: #f5f7fa;
  padding: 40px;
}

.container {
  display: flex;
  width: 1200px;
  margin-left: auto;
  margin-right: auto;

  background-color: #fff;
  box-shadow: 10px 10px 20px 0px hsla(0, 0%, 0%, 0.1);
}

.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.right-side {
  width: 830px;
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;
}

.contacts, .skills {
    padding-left: 40px;
}
```

## Day 5
  1. (css-30) Theme: html ссылка для скачивания файла
```html
<aside class="left-side">
  <section class="skills">
    <!--  Список софт. навыков  -->
  </section>
  <section class="widget">
    <a class="widget-link" href="resume">Скачать резюме</a>
  </section>
</aside>
```
  2. (css-31) Theme: text-transform: uppercase + текст
```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills {
  margin-bottom: 52px;
}

.widget-link {
  font-size: 12px;
  font-weight: bold;
  text-decoration: none;
  text-transform: uppercase;
  line-height: 1;
}
```
  3. (css-32) Theme: цвет, фон и тень
```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills {
  margin-bottom: 52px;
}

.widget-link {
  font-size: 12px;
  font-weight: bold;
  text-decoration: none;
  text-transform: uppercase;
  line-height: 1;

  color: #fff;
  background-color: #ff6b08;
  box-shadow: 0px 8px 43px 0px rgba(255, 107, 8, 0.588);
}
```
  4. (css-33) Theme: hover + active
```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills {
  margin-bottom: 52px;
}

.widget-link {
  font-size: 12px;
  font-weight: bold;
  text-decoration: none;
  text-transform: uppercase;
  line-height: 1;
  color: #fff;
  background-color: #ff6b08;
  box-shadow: 0px 8px 43px 0px rgba(255, 107, 8, 0.588);
}

.widget-link:hover {
    box-shadow: 0px 8px 23px 0px #ff6b0896;
}

.widget-link:active {
    box-shadow: inset 0px 2px 5px 0px #ff6b0896;
}
```
  5. (css-34) Theme: padding
```css
.photo,
.contacts,
.skills,
.widget {
  margin-bottom: 60px;
}

.contacts,
.skills,
.widget  {
  padding-left: 40px;
}
```
  6. (css-35) Theme: подключение готовой анимации с помощью классов
```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.photo,
.contacts,
.skills,
.widget{
  margin-bottom: 60px;
}

.contacts,
.skills,
.widget {
  padding-left: 40px;
}

.widget {
  padding-left: 40px;
  min-height: 60px;
}
.widget-link {
  padding-top: 20px;
  padding-right: 43px;
  padding-bottom: 20px;
  padding-left: 43px;

  text-decoration: none;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: bold;
  line-height: 1;

  color: #fff;
  background-color: #ff6b08;
  box-shadow: 0px 8px 43px 0px rgba(255, 107, 8, 0.588);
}

.widget-link:hover {
    box-shadow: 0px 8px 23px 0px #ff6b0896;
}

.widget-link:active {
    box-shadow: inset 0px 2px 5px 0px #ff6b0896;
}

.photo:hover {
  animation: swing 1s;
  transform-origin: center;
}

.widget:hover {
  animation:  heartBeat 1s;
  transform-origin: center;
}
```
  7. (css-36) Theme: атрибут download
```css
<section class="skills">
  <!--  Раздел навыков  -->
</section>
<section class="widget">
  <a class="widget-link" href="./resume.zip" download>Скачать резюме</a>
</section>
```