<details open>
<summary>Заголовки</summary>

Заголовки - это теги, которые обозначают важность смысловых разделов разного уровня. 

Тегами заголовков мы структурируем контент.

![скриншот сайта с примером заголовков h1 h2](/img/code/html-3/headers.svg)

```html
<h1>Заголовок всей страницы</h1>

<h2>Заголовок всей статьи</h2>
<p>
  Lorem ipsum dolor sit amet consectetur
  adipisicing elit. Unde voluptas
  necessitatibus, doloremque vero pariatur
  aut delectus neque sint maxime!
</p>

```
#### Пример отображения в браузере
<div class="browser">
  <h1>Заголовок всей страницы</h1>
  <h2>Заголовок всей статьи</h2>
  <p>
  Lorem ipsum dolor sit amet consectetur
  adipisicing elit. Unde voluptas
  necessitatibus, doloremque vero pariatur
  aut delectus neque sint maxime!
  </p>
</div>

#### Заголовок h2

Заголовок `h2` - это заголовок второго уровня, следующий после `h1`.

Вот пример заголовка `h2`:

```html
<h2>Заголовок второго уровня</h2>
```

<div class="browser">
   <h2>Заголовок второго уровня</h2>
</div>

</details>

## Задание:

Напишите заголовок h2 с текстом **Projects**.

#### Критерии приема задания:

- Код должен содержать заголовок второго уровня
- Текст заголовка должен быть равен **Projects**
- Других тегов в тексте быть не должно
