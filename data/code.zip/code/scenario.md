## Day 1

правая часть html  (html-1 - html-10)

    1) h1
    2) p
    3) h3
    4) ol li
    5) a
    6) h3
    7) ul li
    8) повтор
    9) повтор
    10) section
---

## Day 2

левая часть html  (html-11 - html-15)

    11) img
    12) повтор
    13) href tel mailto
    14) повтор Tech Skills
    15) aside .container
---

## Day 3

правая часть css (css-1 - css-17)

#### Bio 
css-1 - css-5

    1) css-1 font-size
    2) css-2 line-height
    3) css-3 color
    4) css-4 DRY
    5) css-5 margin

#### Projects 
css-6 - css-8

    6) css-6 стили
    7) css-7 псевдокласс - добавить теорию и пример
    8) css-8 стили + псевдокласс

#### Work experience 
css-9 - css-15

    9) css-9 font-size + line-height
    10) css-10 стили + color
    11) css-11 стили + .accent {color}
    12) css-12 стили + margin-bottom
    13) css-13 class to html
    14) css-14 experience + margin-bottom

#### Education 
css-15    

    15)css-15 education

#### Final right side
css-16 - css-17

     16) css-16  margin-bottom для section
     17) css-17 wrapper + padding
---

## Day 4
левая часть css и обе части вместе

    1) css-18  aside
    2) css-19 photo
    
#### Contacts
css-20 - css-22

    3) css-20 font-size line-height
    4) css-21 color
    5) css-22 hover + color

#### Skills
css-23 - css-25

    6) css-23 цвета и текст
    7) css-24 общий пример before + after  + &copy; css-25 before + `\2022`

#### Left-side
css-25 - css-26

    8) css-25 section + margin-bottom
    9) css-26 left-side + padding-left

#### Both-side
css-27 - css-29

     10) css-27 flexbox пример flexbox
     11) css-28 Центрирование контейнера
     12) css-29 фон body, container и тень
---


## Day 5
кнопка из ссылки, анимация кнопки

    1) css-30  html ссылка для скачивания файла
    2) css-31 text-transform: uppercase + текст
    3) css-32  цвет, фон и тень
    4) css-33  hover + active БЕЗ МАКЕТА
    5) css-34  padding-left: 40px кнопка из ссылки (padding)
    6) css-35  подключение готовой анимации с помощью классов
    7) css-36  добавляем атрибут download (мы меняем имя файла)
---
