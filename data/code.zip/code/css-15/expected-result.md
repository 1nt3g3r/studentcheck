#css

```css
.education-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;

  margin-bottom: 26px;
}

.education-degree {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;

  margin-bottom: 16px;
}

.education-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;

  margin-bottom: 18px;
}

.accent {
  color: #ff6b08;
}
```
