#css

```css
.bio-title {
  font-size: 45px;
  line-height: 2;
}

.bio-title ,
.bio-occupation {
  color: #2a2a2a;
}

.bio-occupation,
.bio-about {
  font-size: 14px;
  line-height: 1.714;
}

.bio-about {
  color: #595959;
}
```
