<details open>
<summary>Абзац (параграф)</summary>

#### Абзац

Абзац - универсальный контейнер для группировки текста.

По умолчанию абзац начинается с новой строки и имеет вертикальные отступы, которые можно будет изменить в CSS.

Отдельные абзацы в терминах HTML называются *параграфами*. Текст каждого параграфа оборачивается в тег **p**.

Вот пример параграфа:

```html
<p>
  My first paragraph. Lorem ipsum dolor sit
  amet, consectetur adipisicing elit.
</p>

<p>
  My second paragraph.  Neque eligendi, a
  eaque, esse itaque porro non exercitation -
  em odio earum quos perferendis!
</p>
```

#### Пример отображения в браузере
<div class="browser">
   <p>
     My first paragraph. Lorem ipsum dolor sit
     amet, consectetur adipisicing elit.
   </p>
   
   <p>
     My second paragraph.  Neque eligendi, a
     eaque, esse itaque porro non exercitation -
     em odio earum quos perferendis!
   </p>
</div>

</details>

## Задание:

Добавьте два тега абзацев. Один для названия профессии, а второй для биографии. Не удаляйте существующие теги.

#### Критерии приема задания:

- в коде есть два параграфа и заголовок `h1`
- текст первого параграфа - **Front-end developer**
- текст второго параграфа не должен быть пустым
- других тегов в коде не должно быть