#html

```html
<section class="jobs">
  <h2 class="jobs-title">Employment history</h2>

  <h3 class="jobs-occupation">
    Front-end developer at <span class="accent">Freelance</span>
  </h3>
  <p class="jobs-time">September 2019 - up to now</p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet.</li>
    <li class="experience-item">Quaerat corrupti eum harum eveniet?</li>
    <li class="experience-item">Sit quasi libero facilis ea?</li>
  </ul>

  <h3 class="jobs-occupation">
    Manager at <span class="accent">Roga &amp; Kopyta New</span>
  </h3>
  <p class="jobs-time">March 2015 - October 2018</p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet...</li>
    <li class="experience-item">Risus commodo viverra maecenas.</li>
    <li class="experience-item">Lorem ipsum dolor sit amet..</li>
  </ul>

  <h3 class="jobs-occupation">
    Manager at <span class="accent">Roga &amp; Kopyta LLC</span>
  </h3>
  <p class="jobs-time">June 2014 - February 2015/p></p>
  <ul class="experience">
    <li class="experience-item">Lorem ipsum dolor sit amet...</li>
    <li class="experience-item">Risus commodo viverra maecenas.</li>
    <li class="experience-item">Lorem ipsum dolor sit amet..</li>
  </ul>
</section>
```
