#css

```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.contacts-title {
  font-size: 22px;
  line-height: 1.091;
}

.contacts-item {
  font-size: 14px;
  line-height: 1.714;
}

.contacts-link {
  color: #fff;
  opacity: 0.6;
}

.contacts-link:hover {
  opacity: 1;
}
```
