<details open>
 <summary>
   Наведение курсора и изменение прозрачности
 </summary>

#### Пример изменения прозрачности у ссылки при наведении курсора.

```html
<a href="#" class="link">
    Ссылка
</a>
```

```css
.link {
    text-decoration: none;
    color: #f00;
    opasity: .5;
}

.link:hover {
    opacity: 1;
}
```
#### Пример отображения в браузере
<div class="browser">
  <style>
    .browser .link {
        text-decoration: none;
        color: #f00;
        opasity: .5;
    }
    .browser .link:hover {
        opacity: 1;
    }
  </style>
   <a href="#" class="link">
    Ссылка
</a>
</div>

</details>

## Задание

Задайте значение 1 прозрачности при наведении курсора на ссылку. Сделайте это при помощи селектора `:hover`.


#### Критерии приема задания:
- Должно быть CSS правило с селектором события `:hover` для ссылки
- Значение opacity должно быть `1` для селектора события `:hover` у ссылки.
- Других селекторов, свойств или значений быть не должно.
