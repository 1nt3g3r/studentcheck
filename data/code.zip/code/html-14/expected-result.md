## html

```html
<section>
  <h2>Tech skills</h2>

  <ul>
    <li>HTML</li>
    <li>CSS</li>
    <li>Git</li>
    <li>JavaScript</li>
    <li>React</li>
    <li>Node.js</li>
  </ul>
</section>

<section>
  <h2>Soft skills</h2>

  <ul>
    <li>Scrum</li>
    <li>Agile</li>
    <li>GTD</li>
    <li>Teamwork</li>
  </ul>
</section>
```