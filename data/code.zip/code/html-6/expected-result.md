## html

```html
<h2>Employment history</h2>

<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
```