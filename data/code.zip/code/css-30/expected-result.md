#html

```html
<aside class="left-side">
  <section class="skills">
    <!--  Список софт. навыков  -->
  </section>
  <section class="widget">
    <a class="widget-link" href="resume">Скачать резюме</a>
  </section>
</aside>
```
