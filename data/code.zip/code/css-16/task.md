 <details open>
 <summary>
    Смещение соседних элементов section
 </summary>

</details>

## Задание

К элементам section с классами `bio`,`projects`,`jobs` и `education` добавьте margin-bottom.

#### Критерии приема задания:

- В качестве селектора должны быть имена классов `bio`,`projects`,`jobs` и `education`.
- Значение  margin-bottom должно быть `60px`.
- Других селекторов, свойств или значений быть не должно.
