#css

```css
.bio,
.projects,
.jobs,
.education {
  margin-bottom: 60px;
}
```
