#css

```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills-title {
  font-size: 22px;
  line-height: 1.091;
}

.skills-item {
  font-size: 14px;
  line-height: 1.714;
}

.skills-list {
  list-style: none;
  padding-left: 0;
}

.skills-item::before {
  content: '\2022';
  margin-right: 8px;
  color: #ff6b08;
  font-size: 18px;
}
```
