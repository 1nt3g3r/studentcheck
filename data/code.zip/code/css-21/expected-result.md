#css

```css
.left-side {
  width: 370px;
  background-color: #1e2939;
}

.contacts-title {
  font-size: 22px;
  line-height: 1.091;
  color: #fff;
}

.contacts-item {
  font-size: 14px;
  line-height: 1.714;
  color: #fff;
}

.contacts-link {
  color: #fff;
  opacity: 0.6;
}
```
