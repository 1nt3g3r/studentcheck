##html

```html
<img
  src="photo.jpg"
  alt="Моя фотография"
  width="370"
/>
```