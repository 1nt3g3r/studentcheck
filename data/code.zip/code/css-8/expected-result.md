#css

```css
.projects-title {
  margin-bottom: 14px;
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;
}

.projects-link {
  color: #220fdc;
  font-size: 14px;
  line-height: 1.714;
}

.projects-link:hover {
  color: #ff6b08;
}
```
