## html

```html
<section>
  <h2>Contacts</h2>

  <ul>
    <li>Phone: <a href="tel:+380951111111">+38 095 111 11 11</a></li>
    <li>Email: <a href="mailto:chornyiav@gmail.com">chornyiav@gmail.com</a></li>
  </ul>
</section>
```