#css

```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
  color: #fff;
}

.skills {
  margin-bottom: 52px;
}

.widget-link {
  font-size: 12px;
  font-weight: bold;
  text-decoration: none;
  text-transform: uppercase;
  line-height: 1;

  color: #fff;
  background-color: #ff6b08;
  box-shadow: 0px 8px 43px 0px rgba(255, 107, 8, 0.588);
}
```
