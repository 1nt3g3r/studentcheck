#css

```css
.bio-title {
  font-size: 45px;
  line-height: 2;
  color: #2a2a2a;
}

.bio-occupation {
  font-size: 14px;
  line-height: 1.714;
  color: #2a2a2a;
}

.bio-about {
  font-size: 14px;
  line-height: 1.714;
  color: #595959;
}
```