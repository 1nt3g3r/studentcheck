#css

```css
.bio-title {
  font-size: 45px;
  line-height: 2;
}

.bio-occupation {
  font-size: 14px;
  line-height: 1.714;
}

.bio-about {
  font-size: 14px;
  line-height: 1.714;
}
```
