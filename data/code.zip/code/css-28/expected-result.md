#css

```css
.container {
  display: flex;
  width: 1200px;
  margin-left: auto;
  margin-right: auto;
}

.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.right-side {
  width: 830px;
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;
}

.contacts, .skills {
    padding-left: 40px;
}
```
