#css

```css
.jobs-title {
  font-size: 22px;
  line-height: 1.091;
}

.jobs-occupation {
  font-size: 16px;
  line-height: 1.5;
}

.jobs-time {
  font-size: 12px;
  line-height: 2;
}

.experience-item {
  font-size: 14px;
  line-height: 1.714;
}
```
