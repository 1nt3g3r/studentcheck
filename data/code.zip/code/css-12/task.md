<details open>
 <summary>
    Отступы
 </summary>

</details>

## Задание

Добавьте отступы  элементам с классами `jobs-title `, `jobs-occupation`, `jobs-time` и `experience-item`.


#### Критерии приема задания:

- В качестве селектора должны быть имена классов `jobs-title `, `jobs-occupation`, `jobs-time` и `experience-item`.
- Значения margin-bottom должны быть `10px`, `16px`, `18px` и `26px`.
- Других селекторов, свойств или значений быть не должно.
