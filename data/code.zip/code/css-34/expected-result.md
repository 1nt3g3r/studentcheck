#css

```css
.photo,
.contacts,
.skills,
.widget {
  margin-bottom: 60px;
}

.contacts,
.skills,
.widget  {
  padding-left: 40px;
}
```
