#css

```css
.contacts-link {
  color: #595959;
  text-decoration: none;
}

.contacts-link:hover {
  color: #ff6b08;
}
```
