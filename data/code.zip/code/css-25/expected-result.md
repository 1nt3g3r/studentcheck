#css

```css
.photo,
.contacts,
.skills {
  margin-bottom: 60px;
}
```
