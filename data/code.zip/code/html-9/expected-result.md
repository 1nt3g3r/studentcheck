## html

```html
<h2>Education</h2>

<h3>Management, Kharkiv National University of Radioelectronics</h3>
<p>September 2009 - June 2014</p>

<h3>Full Stack Developer, GoIT Courses</h3>
<p>April - November 2020</p>
```