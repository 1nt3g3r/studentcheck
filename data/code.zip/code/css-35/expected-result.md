#css

```css
.left-side {
  width: 370px;
  background-color: #1e2939;
  color: #fff;
}

.photo,
.contacts,
.skills,
.widget{
  margin-bottom: 60px;
}

.contacts,
.skills,
.widget {
  padding-left: 40px;
}

.widget {
  padding-left: 40px;
  min-height: 60px;
}
.widget-link {
  padding-top: 20px;
  padding-right: 43px;
  padding-bottom: 20px;
  padding-left: 43px;

  text-decoration: none;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: bold;
  line-height: 1;

  color: #fff;
  background-color: #ff6b08;
  box-shadow: 0px 8px 43px 0px rgba(255, 107, 8, 0.588);
}

.widget-link:hover {
    box-shadow: 0px 8px 23px 0px #ff6b0896;
}

.widget-link:active {
    box-shadow: inset 0px 2px 5px 0px #ff6b0896;
}

.photo:hover {
  animation: swing 1s;
}

.widget:hover {
  animation:  heartBeat 1s;
}
```
