<details open>
<summary>Анимация изображения и ссылки</summary>

#### анимация CSS

CSS анимация доступна в готовом в виде в бесплатных библиотеках. Нужно только
научиться ее подключать и добавлять к нужным свойствам.

Воспользуемся библиотекой `animate.css`.

Подключение библиотеки происходит довольно легко внутри файла index.html
(смотрите на видео).

Воспользоваться подключенной библиотекой довольно просто. Надо выбрать название
готовой анимации и добавить в CSS правило. Ниже список некоторых названий анимаций:

```html
<ul class="boxes">
  <li class="box box-flash">
    flash
  </li>
  <li class="box box-headShake">
    headShake
  </li>
  <li class="box box-heartBeat">
    heartBeat
  </li>
  <li class="box box-jello">
    jello
  </li>
  <li class="box box-pulse">
    pulse
  </li>
  <li class="box box-rubberBand">
    rubberBand
  </li>
  <li class="box box-bounce">
    bounce
  </li>
</ul>
```

Затем выбрать элемент, добавить псевдокласс hover (если мы хотим анимацию при
наведении курсора) и задать свойству animation значения через пробел - имя
анимации из списка и длительность анимации (например в секундах).

```css
.box-flash:hover {
  animation: flash 1s;
}
.box-headShake:hover {
  animation: headShake 1s;
}
.box-heartBeat:hover {
  animation: heartBeat 1s;
}
.box-jello:hover {
  animation: jello 1s;
}
.box-pulse:hover {
  animation: pulse 1s;
}
.box-rubberBand:hover {
  animation: rubberBand 1s;
}
.box-bounce:hover {
  animation: bounce 1s;
}

```



#### Пример отображения в браузере

<div class="browser">
<style>
  .box-bounce:hover {  animation: bounce 1s;}
  .box-flash:hover {  animation: flash 1s;}
  .box-headShake:hover {  animation: headShake 1s;}
  .box-heartBeat:hover {  animation: heartBeat 1s;}
  .box-jello:hover {  animation: jello 1s;}
  .box-pulse:hover {  animation: pulse 1s;}
  .box-rubberBand:hover {animation: rubberBand 1s;}
  .boxes {
    padding: 20px;
    list-style: none;
  }
  .browser .box {
    margin-bottom: 12px;
    height: 40px;
    line-height: 40px !important;
    text-align: center;
    background-color: #ff6b08ff;
    color: #fff !important;
  }
</style>

  <ul class="boxes">
    <li class="box box-flash">flash</li>
    <li class="box box-headShake">headShake</li>
    <li class="box box-heartBeat">heartBeat</li>
    <li class="box box-jello">jello</li>
    <li class="box box-pulse">pulse</li>
    <li class="box box-rubberBand">rubberBand</li>
    <li class="box box-bounce">bounce</li>
  </ul>
</div>

</details>

## Задание

Добавьте для элементов `photo` и `widget` свойство animation при hover.

#### Критерии приема задания:

- В качестве селектора должны быть классы `photo`, `widget` и `hover`.
- Значение animation для `photo` должно быть `swing 1s`.
- Значение animation для `widget` должно быть `heartBeat 1s`.
- Других селекторов, свойств или значений быть не должно.
