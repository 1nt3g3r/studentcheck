#css

```css
.left-side {
  width: 370px;
  min-height: 370px;
  background-color: #1e2939;
}

.photo {
  width: 370px;
}
```
