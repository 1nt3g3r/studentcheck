#html

```html
<section class="skills">
  <!--  Раздел навыков  -->
</section>
<section class="widget">
  <a class="widget-link" href="https://cutt.ly/7yw4IsY" download>Скачать резюме</a>
</section>

```
