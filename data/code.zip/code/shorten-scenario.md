## Day 1

правая часть html  (html-1 - html-10)

    1) h1
    2) p
    3) h3
    4) ol li
    5) a
    6) h3
    7) ul li
    8) повтор
    9) повтор
    10) section
---

## Day 2

левая часть html  (html-11 - html-15)

    11) img
    12) повтор
    13) href tel mailto
    14) повтор Tech Skills
    15) aside .container
---

## Day 3

правая часть css (css-1 - css-14)

#### Bio 
css-1 - css-5

    1) css-1 font-size
    2) css-2 color
    3) css-3 DRY
    4) css-4 margin

#### Projects 
css-5 - css-7

    5) css-5 стили
    6) css-6 псевдокласс
    7) css-7 стили + псевдокласс

#### Work experience 
css-8 - css-11

    8) css-8 font-size + color + margin-bottom
    9) css-9 стили + .accent {color}
    10) css-10 class to html
    11) css-11 experience + margin-bottom

#### Education 
css-12    

    12)css-12 education

#### Final right side
css-13 - css-14

     13) css-13  margin-bottom для section
     14) css-14 wrapper + padding
---

## Day 4
левая часть css и обе части вместе

    1) css-15 aside
    2) css-16 photo
    
#### Contacts
css-17 - css-18

    3) css-17 font-size color
    4) css-18 hover + color

#### Skills
css-19 - css-20

    5) css-19 цвета и текст
    6) css-20 общий пример before + after  + &copy; css-25 before + `\2022`

#### Left-side
css-21 - css-22

    7) css-21 section + margin-bottom
    8) css-22 left-side + padding-left

#### Both-side
css-23 - css-25

     9) css-23 flexbox пример flexbox
     10) css-24 Центрирование контейнера
     11) css-25 фон body, container и тень
---


## Day 5
кнопка из ссылки, анимация кнопки
css-26 - css-32

    1) css-26  html ссылка для скачивания файла
    2) css-27 text-transform: uppercase + текст
    3) css-28  цвет, фон и тень
    4) css-29  hover + active БЕЗ МАКЕТА
    5) css-30  padding-left: 40px кнопка из ссылки (padding)
    6) css-31  подключение готовой анимации с помощью классов
    7) css-32  добавляем атрибут download (мы меняем имя файла)
---
