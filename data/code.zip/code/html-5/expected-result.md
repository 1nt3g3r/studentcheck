## html

```html
<h2>Projects</h2>

<ol>
  <li>
    <a href="https://lovecamp.allinsol.com">https://lovecamp.allinsol.com</a>
  </li>
  <li>
    <a href="https://cryptohub.goit.ua">https://cryptohub.goit.ua</a>
  </li>
  <li>
    <a href="https://kidslike.goit.co.ua">https://kidslike.goit.co.ua</a>
  </li>
</ol>
```