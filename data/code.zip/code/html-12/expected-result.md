## html

```html
<section>
  <h2>Contacts</h2>

  <ul>
    <li>Phone: +38 095 111 11 11</li>
    <li>Email: chornyiav@gmail.com</li>
  </ul>
</section>
```