<details open>
<summary>Семантическое сходство</summary>

#### text-transform

Внешний вид - это задача CSS. Можно написать текст в html в любом регистре - большими или маленькими буквами. 
Но с помощью свойства CSS **text-transform** мы можем это изменить.

Чтобы все буквы были заглавными требуется значение `uppercase`. Пример:

```html
<h2 class="upper">Привет, друг!</h2>
<h2 class="lower">Привет, друг!</h2>
<h2 class="cap">Привет, друг!</h2>
```

```css
.upper {
    text-transform: uppercase;
}
.lower {
    text-transform: lowercase;
}
.cap {
    text-transform: capitalize;
}
```

</details>


## Задание

Задайте оформление текста ссылки по макету.


#### Критерии приема задания:
- Добавьте CSS правило с селектором класса `widget-link`.
- Значение  font-size должно быть  `12px`.
- Значение  font-weight должно быть  `bold`.
- Значение  text-decoration должно быть  `none`.
- Значение  text-transform должно быть  `uppercase`.
- Значение  line-height должно быть  `1`.
- Других селекторов, свойств или значений быть не должно.
