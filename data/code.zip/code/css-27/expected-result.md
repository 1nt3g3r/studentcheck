#css

```css
.container {
  display: flex;
  width: 1200px;
}

.left-side {
  background-color: #1e2939;
  color: #fff;

  width: 370px;
}

.right-side {
  padding-left: 80px;
  padding-right: 200px;
  padding-top: 68px;
  padding-bottom: 68px;

  width: 830px;
}

.contacts, .skills {
    padding-left: 40px;
}
```
