<details open>
 <summary>
    Flex
 </summary>

#### Расположение блоков по умолчанию

По умолчанию элементы с именами div, section, aside и т.п. размещаются друг под
другом. Это происходит по двум причинам:

1. Ширина таких элементов всегда 100%, т.е. свободного места встать рядом
   другому элементу нет.
2. У таких элементов есть невидимые символы переноса строки. Т.е. даже если
   задать достаточную ширину, знак переноса сместит соседний элемент вниз

#### Flex - размещение по горизонтали

Чтобы отменить действие знаков переноса и поставить элементы в один ряд
достаточно задать свойству **display** значение **flex**. При этом ширина будет
выбираться браузером автоматически.

Чтобы ширина блоков была как на макете потребуется задать свойству width
значения (например в px).

```html
<div class="no-flex-container">
  <div class="box red"></div>
  <div class="box green"></div>
</div>
<div class="flex-container">
  <div class="box red"></div>
  <div class="box green"></div>
</div>
```

```css
.box {
  width: 50px;
  height: 50px;
  margin: 10px;
}
.red {
  background-color: #f00;
}
.green {
  background-color: #080;
}
.no-flex-container,
.flex-container {
  padding: 10px;
  margin: 10px;
  background-color: orange;
}
.flex-container {
  display: flex;
}
```

#### Пример отображения в браузере
<div class="browser">
<style>
.browser .box {
  width: 50px;
  height: 50px;
  margin: 10px;
}
.browser .red {
  background-color: #f00;
}
.browser .green {
  background-color: #080;
}
.browser .no-flex-container,
.browser .flex-container {
  padding: 10px;
  margin: 10px;
  background-color: orange;
}
.browser .flex-container {
  display: flex;
}
</style>
<div class="no-flex-container">
  <div class="box red"></div>
  <div class="box green"></div>
</div>
<div class="flex-container">
  <div class="box red"></div>
  <div class="box green"></div>
</div>
</div>

</details>

## Задание

Задайте display со значением flex элементу с классом `container` и задайте
ширину элементам с классами `left-side` и `right-side`.

#### Критерии приема задания:

- В качестве селектора должны быть классы  `container`, `left-side`, `right-side`, `contacts` и `skills`.
- Значение display должно быть `flex`.
- Значение width должно быть `370px` и `830px`.
- Других селекторов, свойств или значений быть не должно.
