#css

```css
.projects-title {
  font-size: 22px;
  line-height: 1.091;
  color: #2a2a2a;
  margin-bottom: 14px;
}

.projects-link {
  font-size: 14px;
  line-height: 1.714;
  color: #220fdc;
}

```
