## html

```html
<section>
  <h1>Anton Chornyi</h1>
  <p>Front-end developer</p>
  <p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet odio adipisci
    illo, earum atque quae, sequi magni consectetur sit perferendis sunt laborum
    ipsum quas. A incidunt temporibus aut harum ad.
  </p>
</section>

<section>
  <h2>Project</h2>

  <ol>
    <li>
      <a href="https://lovecamp.allinsol.com/">https://lovecamp.allinsol.com</a>
    </li>
    <li>
      <a href="https://cryptohub.goit.ua/">https://cryptohub.goit.ua</a>
    </li>
    <li>
      <a href="https://kidslike.goit.co.ua/">https://kidslike.goit.co.ua</a>
    </li>
  </ol>
</section>

<section>
  <h2>Employment history</h2>

<h3>Front-end developer at Freelance</h3>
<p>September 2019 - up to now</p>
<ul>
    <li>Lorem ipsum dolor sit amet...</li>
    <li>Risus commodo viverra maecenas. </li>
    <li>Lorem ipsum dolor sit amet...</li>
</ul>

<h3>Manager at Roga &amp; Kopyta New</h3>
<p>March 2015 - October 2018</p>
<ul>
    <li>Lorem ipsum dolor sit amet...</li>
    <li>Risus commodo viverra maecenas. </li>
    <li>Lorem ipsum dolor sit amet...</li>
</ul>

<h3>Manager at Roga &amp; Kopyta LLC</h3>
<p>June 2014 - February 2015</p>
<ul>
    <li>Lorem ipsum dolor sit amet...</li>
    <li>Risus commodo viverra maecenas. </li>
    <li>Lorem ipsum dolor sit amet...</li>
</ul>
</section>

<section>
  <h2>Education</h2>

  <h3>Management, Kharkiv National University of Radioelectronics</h3>
  <p>September 2009 - June 2014</p>

  <h3>Full Stack Developer, GoIT Courses</h3>
  <p>April - November 2020</p>
</section>
```