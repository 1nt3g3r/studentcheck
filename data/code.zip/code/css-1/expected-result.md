#css

```css
.bio-title {
  font-size: 45px;
}

.bio-occupation {
  font-size: 14px;
}

.bio-about {
  font-size: 14px;
}
```
