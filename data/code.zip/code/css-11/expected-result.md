#css

```css
.jobs-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;
}

.jobs-occupation {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;
}

.jobs-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;
}

.experience-item {
  color: #595959;
  font-size: 14px;
  line-height: 1.714;
}

.accent {
  color: #ff6b08;
}
```
