#css

```css
.jobs-title {
  color: #2a2a2a;
  font-size: 22px;
  line-height: 1.091;

  margin-bottom: 26px;
}

.jobs-occupation {
  color: #2a2a2a;
  font-size: 16px;
  line-height: 1.5;

  margin-bottom: 16px;
}

.jobs-time {
  color: #828282;
  font-size: 12px;
  line-height: 2;

  margin-bottom: 18px;
}

.experience-item {
  color: #595959;
  font-size: 14px;
  line-height: 1.714;

  margin-bottom: 10px;
}

.accent {
  color: #ff6b08;
}

.experience {
  margin-bottom: 28px;
}
```
